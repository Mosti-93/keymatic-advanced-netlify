'use client'
import { useState } from "react";
import Link from "next/link";

const initialData = [
  {
    roomNo: '101',
    machine: { id: 'M1', name: 'Main Locker', location: 'Cairo' },
    owner: { name: 'John Doe', email: 'john@example.com' },
    client: { name: 'Alice Brown', email: 'alice@example.com', checkIn: '2025-07-20', checkOut: '2025-07-25' }
  },
  {
    roomNo: '102',
    machine: { id: 'M2', name: 'Secondary Locker', location: 'Alexandria' },
    owner: { name: 'Jane Smith', email: 'jane@example.com' },
    client: null // No client = ready
  },
  {
    roomNo: '103',
    machine: { id: 'M3', name: 'VIP Locker', location: 'Giza' },
    owner: { name: 'Michael Green', email: 'mike@example.com' },
    client: { name: 'Charlie Black', email: 'charlie@example.com', checkIn: '2025-07-10', checkOut: '2025-07-15' }
  }
];

const getStatus = (client) => {
  if (client && new Date(client.checkOut) >= new Date()) {
    return <span className="inline-flex items-center px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">🟢 In Use</span>;
  }
  return <span className="inline-flex items-center px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium">🔵 Ready</span>;
};

export default function Dashboard() {
  const [data, setData] = useState(initialData);
  const [sortConfig, setSortConfig] = useState({ key: '', direction: '' });

  const sortedData = [...data].sort((a, b) => {
    if (!sortConfig.key) return 0;
    const aValue = a[sortConfig.key] || a.machine[sortConfig.key] || a.owner[sortConfig.key] || (a.client ? a.client[sortConfig.key] : '');
    const bValue = b[sortConfig.key] || b.machine[sortConfig.key] || b.owner[sortConfig.key] || (b.client ? b.client[sortConfig.key] : '');
    if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
    if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
    return 0;
  });

  const requestSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold text-gray-900">Keymatic Dashboard</h1>
        </div>
      </header>
      <main className="max-w-7xl mx-auto py-10 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-10">
          <Link href="/create-key" className="flex items-center justify-center p-6 bg-blue-600 text-white rounded-xl shadow hover:bg-blue-700 transition text-lg font-semibold">🔑 Create Key</Link>
          <Link href="/create-machine" className="flex items-center justify-center p-6 bg-green-600 text-white rounded-xl shadow hover:bg-green-700 transition text-lg font-semibold">🏭 Create Machine</Link>
          <Link href="/create-owner" className="flex items-center justify-center p-6 bg-purple-600 text-white rounded-xl shadow hover:bg-purple-700 transition text-lg font-semibold">👤 Add Owner</Link>
          <Link href="/link-key" className="flex items-center justify-center p-6 bg-yellow-500 text-white rounded-xl shadow hover:bg-yellow-600 transition text-lg font-semibold">🔗 Link Key</Link>
          <Link href="/link-owner" className="flex items-center justify-center p-6 bg-pink-500 text-white rounded-xl shadow hover:bg-pink-600 transition text-lg font-semibold">🔗 Link Owner</Link>
          <Link href="/add-client" className="flex items-center justify-center p-6 bg-indigo-500 text-white rounded-xl shadow hover:bg-indigo-600 transition text-lg font-semibold">👥 Add Client</Link>
        </div>
        <div className="bg-white shadow rounded-lg p-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center">📋 Full Database Table</h2>
          <div className="overflow-x-auto">
            <table className="min-w-full border border-gray-300 rounded-lg">
              <thead className="bg-gray-100">
                <tr>
                  {['roomNo', 'name', 'location', 'status', 'owner', 'client', 'checkIn', 'checkOut'].map((header) => (
                    <th
                      key={header}
                      onClick={() => requestSort(header)}
                      className="px-4 py-2 border border-gray-300 text-xs font-medium text-gray-500 uppercase cursor-pointer hover:bg-gray-200">
                      {header.replace(/([A-Z])/g, ' $1').toUpperCase()} {sortConfig.key === header ? (sortConfig.direction === 'asc' ? '▲' : '▼') : ''}
                    </th>
                  ))}
                  <th className="px-4 py-2 border border-gray-300 text-xs font-medium text-gray-500 uppercase">EDIT</th>
                </tr>
              </thead>
              <tbody>
                {sortedData.map((entry, idx) => (
                  <tr key={idx} className="hover:bg-gray-50">
                    <td className="px-4 py-2 border border-gray-300">{entry.roomNo}</td>
                    <td className="px-4 py-2 border border-gray-300">{entry.machine.id} - {entry.machine.name}</td>
                    <td className="px-4 py-2 border border-gray-300">{entry.machine.location}</td>
                    <td className="px-4 py-2 border border-gray-300">{getStatus(entry.client)}</td>
                    <td className="px-4 py-2 border border-gray-300">{entry.owner.name}<br /><span className="text-gray-500 text-xs">{entry.owner.email}</span></td>
                    <td className="px-4 py-2 border border-gray-300">{entry.client ? entry.client.name : '—'}<br /><span className="text-gray-500 text-xs">{entry.client ? entry.client.email : ''}</span></td>
                    <td className="px-4 py-2 border border-gray-300">{entry.client ? entry.client.checkIn : '—'}</td>
                    <td className="px-4 py-2 border border-gray-300">{entry.client ? entry.client.checkOut : '—'}</td>
                    <td className="px-4 py-2 border border-gray-300 text-blue-600 hover:underline cursor-pointer">Edit</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}
